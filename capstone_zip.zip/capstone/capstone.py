import os, random, time, decoder
from PIL import Image
import numpy as np
import tensorflow as tf

# Killing optional CPU driver warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'

def load_data():
    vocab = open('data/sample/latex_vocab.txt').read().split('\n')
    vocab_to_idx = dict([ (vocab[i],i) for i in range(len(vocab))])
    formulas = open('data/sample/formulas.lst').read().split('\n')

    def formula_to_indices(formula):
        formula = formula.split(' ')
        res = [0]

        for token in formula:
            if token in vocab_to_idx:
                res.append( vocab_to_idx[token] + 4 )
            else:
                res.append(2)

        res.append(1)
        return res


    formulas = [formula_to_indices(word) for word in formulas]

    train = open('data/sample/train.lst').read().split('\n')[:-1]
    val = open('data/sample/validate.lst').read().split('\n')[:-1]
    test = open('data/sample/test.lst').read().split('\n')[:-1]

    def import_images(datum):
        datum = datum.split(' ')
        img = np.array(Image.open('data/sample/images_processed/'+datum[1]+'.png').convert('L'))
        return (img, formulas[ int(datum[0]) ])

    train = map(import_images, train)
    val = map(import_images, val)
    test = map(import_images, test)

    return train, val, test

def batchify(data, batch_size):
    res = {}
    for datum in data:
        if datum[0].shape not in res:
            res[datum[0].shape] = [datum]
        else:
            res[datum[0].shape].append(datum)
    batches = []

    for size in res:
        group = sorted(res[size], key= lambda x: len(x[1]))
        for i in range(0, len(group), batch_size):
            images = list(map(lambda x: np.expand_dims(np.expand_dims(x[0],0),3), group[i:i+batch_size]))
            batch_images = np.concatenate(images, 0)
            seq_len = max([ len(x[1]) for x in group[i:i+batch_size]])

            def preprocess(x):
                arr = np.array(x[1])
                pad = np.pad( arr, (0, seq_len - arr.shape[0]), 'constant', constant_values = 3)

                return np.expand_dims( pad, 0)

            labels = list(map( preprocess, group[i:i+batch_size]))
            batch_labels = np.concatenate(labels, 0)


            too_big = [(160,400),(100,500),(100,360),(60,360),(50,400), (100,800), (200,500), (800,800), (100,600)] # these are only for the test set

            if batch_labels.shape[0] == batch_size and not (batch_images.shape[1],batch_images.shape[2]) in too_big:
                batches.append( (batch_images, batch_labels) )

    return batches

class Model:
    def __init__(self, inp, batch_size, num_rows, num_columns, dec_seq_length):
        self.batch_size = batch_size
        self.enc_lstm_dim = 256
        self.feat_size = 64
        self.dec_lstm_dim = 512
        self.vocab_size = 503
        self.embedding_size = 80
        self.dec_seq_len = dec_seq_length

        self.inp = inp
        self.num_rows = num_rows
        self.num_columns = num_columns
        self.convolution_output = self.convolution()
        self.encoder_output = self.encoder_application()
        self.decoder_output = self.decoder_application()

    def convolution(self):
        w_conv1 = tf.Variable(tf.truncated_normal([3,3,1,512], stddev=0.1))
        b_conv1 = tf.Variable(tf.constant(0.1, shape=[512]))
        h_conv1 = tf.nn.relu(tf.nn.conv2d(self.inp, w_conv1, strides=[1, 1, 1, 1], padding='SAME') + b_conv1)
        h_bn1 = tf.contrib.layers.batch_norm(h_conv1)

        w_conv2 = tf.Variable(tf.truncated_normal([3,3,512,512], stddev=0.1))
        b_conv2 = tf.Variable(tf.constant(0.1, shape=[512]))
        h_pad2 = tf.pad(h_bn1, [[0,0],[1,1],[1,1],[0,0]], "CONSTANT")
        h_conv2 = tf.nn.relu(tf.nn.conv2d(h_pad2, w_conv2, strides=[1, 1, 1, 1], padding='SAME') + b_conv2)
        h_bn2 = tf.contrib.layers.batch_norm(h_conv2)
        h_pool2 = tf.nn.max_pool(h_bn2, ksize=[1, 1, 2, 1], strides=[1, 1, 2, 1], padding='SAME')

        w_conv3 = tf.Variable(tf.truncated_normal([3, 3, 512, 256], stddev=0.1))
        b_conv3 = tf.Variable(tf.constant(0.1, shape=[256]))
        h_pad3 = tf.pad(h_pool2, [[0,0],[1,1],[1,1],[0,0]], "CONSTANT")
        h_conv3 = tf.nn.relu(tf.nn.conv2d(h_pad3, w_conv3, strides=[1, 1, 1, 1], padding='SAME') + b_conv3)
        h_pool3 = tf.nn.max_pool(h_conv3, ksize=[1, 2, 1, 1], strides=[1, 2, 1, 1], padding='SAME')

        w_conv4 = tf.Variable(tf.truncated_normal([3, 3, 256, 256], stddev=0.1))
        b_conv4 = tf.Variable(tf.constant(0.1, shape=[256]))
        h_pad4 = tf.pad(h_pool3, [[0,0],[1,1],[1,1],[0,0]], "CONSTANT")
        h_conv4 = tf.nn.relu(tf.nn.conv2d(h_pad4, w_conv4, strides=[1, 1, 1, 1], padding='SAME') + b_conv4)
        h_bn4 = tf.contrib.layers.batch_norm(h_conv4)

        w_conv5 = tf.Variable(tf.truncated_normal([3, 3, 256, 128], stddev=0.1))
        b_conv5 = tf.Variable(tf.constant(0.1, shape=[128]))
        h_pad5 = tf.pad(h_bn4, [[0,0],[1,1],[1,1],[0,0]], "CONSTANT")
        h_conv5 = tf.nn.relu(tf.nn.conv2d(h_pad5, w_conv5, strides=[1, 1, 1, 1], padding='SAME') + b_conv5)
        h_pool5 = tf.nn.max_pool(h_conv5, ksize=[1, 2, 2, 1], strides=[1, 2, 2, 1], padding='SAME')

        w_conv6 = tf.Variable(tf.truncated_normal([3, 3, 128, 64], stddev=0.1))
        b_conv6 = tf.Variable(tf.constant(0.1, shape=[64]))
        h_pad6 = tf.pad(h_pool5, [[0,0],[1,1],[1,1],[0,0]], "CONSTANT")
        h_conv6 = tf.nn.relu(tf.nn.conv2d(h_pad6, w_conv6, strides=[1, 1, 1, 1], padding='SAME') + b_conv6)
        h_pad6 = tf.pad(h_conv6, [[0,0],[2,2],[2,2],[0,0]], "CONSTANT")
        h_pool6 = tf.nn.max_pool(h_pad6, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME')

        return h_pool6

    def encoder_function(self, inp1):
        enc_init_shape = [self.batch_size, self.enc_lstm_dim]

        with tf.variable_scope('encoder_rnn'):
            with tf.variable_scope('forward'):
                lstm_cell_fw = tf.nn.rnn_cell.LSTMCell(self.enc_lstm_dim)
                init_fw = tf.nn.rnn_cell.LSTMStateTuple(tf.get_variable("enc_fw_c", enc_init_shape), tf.get_variable("enc_fw_h", enc_init_shape))
            with tf.variable_scope('backward'):
                lstm_cell_bw = tf.nn.rnn_cell.LSTMCell(self.enc_lstm_dim)
                init_bw = tf.nn.rnn_cell.LSTMStateTuple(tf.get_variable("enc_bw_c", enc_init_shape), tf.get_variable("enc_bw_h", enc_init_shape))

            output, _ = tf.nn.bidirectional_dynamic_rnn(lstm_cell_fw, lstm_cell_bw, inp1, sequence_length=tf.fill([self.batch_size], tf.shape(inp1)[1]), initial_state_fw=init_fw, initial_state_bw=init_bw)

        return tf.concat(output, 2)

    def encoder_application(self):
        fun = tf.make_template('fun', self.encoder_function)
        rows_first = tf.transpose(self.convolution_output, perm=[1, 0, 2, 3])
        res = tf.map_fn(fun, rows_first, dtype=tf.float32)
        encoder_output = tf.transpose(res, perm=[1, 0, 2, 3])

        return encoder_output

    def decoder_application(self):
        dec_lstm_cell = tf.nn.rnn_cell.LSTMCell(self.dec_lstm_dim)
        dec_init_shape = [self.batch_size, self.dec_lstm_dim]
        dec_init_state = tf.nn.rnn_cell.LSTMStateTuple(tf.truncated_normal(dec_init_shape), tf.truncated_normal(dec_init_shape))
        init_words = np.zeros([self.batch_size, 1, self.vocab_size])

        output = decoder.embedding_attention_decoder(dec_init_state,
        tf.reshape(self.encoder_output, [self.batch_size, -1, 2*self.enc_lstm_dim]),
        dec_lstm_cell,
        self.vocab_size,
        self.dec_seq_len,
        self.batch_size,
        self.embedding_size,
        feed_previous=True)

        return output



def main():
    batch_size = 20
    epochs = 100
    lr = 0.1
    min_lr = 0.001

    learning_rate = tf.placeholder(tf.float32)
    inp = tf.placeholder(tf.float32)
    num_rows = tf.placeholder(tf.int32)
    num_columns = tf.placeholder(tf.int32)
    num_words = tf.placeholder(tf.int32)
    true_labels = tf.placeholder(tf.int32)
    start_time = time.time()

    print("Building Model")
    model = Model(inp, batch_size, num_rows, num_columns, num_words)
    model.convolution()
    (output, state) = model.decoder_output

    cross_entropy = tf.reduce_mean(tf.nn.sparse_softmax_cross_entropy_with_logits(logits=output, labels=true_labels))
    train_step = tf.train.AdamOptimizer(learning_rate).minimize(cross_entropy)
    correct_prediction = tf.equal(tf.to_int32(tf.argmax(output, axis=2)), true_labels)
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    print("Loading Data")
    train, val, test = load_data()
    train = batchify(train, batch_size)
    random.shuffle(train)
    val = batchify(val, batch_size)
    test = batchify(test, batch_size)

    print("Running Model")
    sess = tf.Session()

    last_val_acc = 0
    reduce_lr = 0

    sess.run(tf.global_variables_initializer())
    print("Training")
    for i in range(epochs):
        if reduce_lr == 5:
            lr = max(min_lr, lr-0.005)
            reduce_lr = 0
        print("Epoch %d learning rate %.4f" % (i, lr))

        epoch_start_time = time.time()
        batch_50_start = epoch_start_time

        for j in range(len(train)):
            images, labels = train[j]
            if (j < 5) or (j % 50 == 0):
                train_accuracy = sess.run(accuracy, feed_dict={inp: images, true_labels: labels, num_rows: images.shape[1], num_columns:images.shape[2], num_words:labels.shape[1]})

                new_time = time.time()

                print("step %d/%d, training accuracy %g, took %f mins" % (j, len(train), train_accuracy, (new_time - batch_50_start)/60))

                batch_50_start = new_time

            sess.run(train_step, feed_dict={learning_rate: lr, inp: images, true_labels: labels, num_rows: images.shape[1], num_columns: images.shape[2], num_words: labels.shape[1]})
            print("Time for epoch:%f mins" % ((time.time()-epoch_start_time)/60))
            print("Running on Validation Set")

            accs = []
            for j in range(len(val)):
                images, labels = val[j]

                val_accuracy = accuracy.eval(feed_dict={inp: images, true_labels: labels, num_rows: images.shape[1], num_columns: images.shape[2], num_words: labels.shape[1]})
                accs.append(val_accuracy)

            val_acc = sess.run(tf.reduce_mean(accs))
            if (val_acc - last_val_acc) >= 0.01:
                reduce_lr = 0
            else:
                reduce_lr = reduce_lr + 1
            last_val_acc = val_acc

            print("val accuracy" + str(val_acc.eval()))
            print("val accuracy %f" % val_acc.eval())
            print("val accuracy %g" % val_acc)
    return

if __name__ == '__main__':
    main()
